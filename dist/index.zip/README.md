# choirs-submit
Submit a new choir to the choirs of the world map
